import kotlin.math.pow

fun main() {

    4.myPow(2).also {
        println(it)
    }

    3.powV2(2) { res: Int ->
        println("Result: $res")
    }

    "John".displayTypeInfo()
    123.displayTypeInfo()
    true.displayTypeInfo()
    DataType.DoubleType(1.4).displayTypeInfo()
    DataType.UnitType().displayTypeInfo()
}

fun Int.myPow(power: Int) = this.toDouble().pow(power.toDouble()).toInt()

fun Int.powV2(power: Int, lambda: (Int) -> Unit) {
    val result = this.myPow(power)
    lambda(result)
}

fun <T> T.displayTypeInfo() {
    when (this) {
        is String -> println("это String")
        is Int -> println("это Int")
        is DataType.DoubleType -> displayDataTypeInfo()
        is DataType.UnitType -> displayDataTypeInfo()
        else -> println("тип у $this неизвестен")
    }
}

fun DataType.displayDataTypeInfo() {
    when (this) {
        is DataType.DoubleType -> println("это DoubleType со значением ${this.value}")
        is DataType.UnitType -> println("это Unit")
    }
}